<?php

namespace Database\Seeders;

use App\Enums\ContactMessageStatus;
use App\Enums\OrderStatus;
use App\Enums\TechnicianRequestStatus;
use App\Models\ContactMessage;
use App\Models\Order;
use App\Models\Product;
use App\Models\Review;
use App\Models\Technician;
use App\Models\TechnicianRequest;
use App\Models\User;
use Illuminate\Database\Seeder;

/**
 * Quelques commandes, demandes d'intervention, avis et messages afin que les
 * deux tableaux de bord ne soient pas vides à la première ouverture.
 */
class DemoActivitySeeder extends Seeder
{
    public function run(): void
    {
        $customer = User::where('email', 'client@refplomberie.cm')->first();
        $products = Product::with('priceTiers')->take(4)->get();

        if ($customer === null || $products->isEmpty()) {
            return;
        }

        $shippingCost = (int) config('shop.shipping.cost');
        $freeFrom = (int) config('shop.shipping.free_from');

        // ── Favoris ───────────────────────────────────────────────────────
        $customer->favorites()->syncWithoutDetaching(
            $products->take(2)->pluck('id')->all(),
        );

        // ── Commandes ─────────────────────────────────────────────────────
        $orderPlans = [
            ['status' => OrderStatus::Delivered, 'lines' => [[0, 2], [1, 1]]],
            ['status' => OrderStatus::Preparing, 'lines' => [[2, 12]]],
            ['status' => OrderStatus::Pending, 'lines' => [[3, 1], [0, 1]]],
        ];

        foreach ($orderPlans as $index => $plan) {
            $reference = 'CMD-DEMO-'.str_pad((string) ($index + 1), 3, '0', STR_PAD_LEFT);

            if (Order::where('reference', $reference)->exists()) {
                continue;
            }

            $lines = [];
            $subtotal = 0;

            foreach ($plan['lines'] as [$productIndex, $quantity]) {
                $product = $products[$productIndex];
                $unitPrice = $this->tierPrice($product, $quantity);
                $lineTotal = $unitPrice * $quantity;
                $subtotal += $lineTotal;

                $lines[] = [
                    'product_id' => $product->id,
                    'product_name' => $product->name,
                    'unit_price' => $unitPrice,
                    'quantity' => $quantity,
                    'line_total' => $lineTotal,
                ];
            }

            $shipping = $subtotal >= $freeFrom ? 0 : $shippingCost;

            $order = Order::create([
                'reference' => $reference,
                'user_id' => $customer->id,
                'customer_name' => $customer->name,
                'customer_phone' => $customer->phone ?? '+237 690 11 22 33',
                'customer_address' => $customer->address,
                'status' => $plan['status'],
                'subtotal' => $subtotal,
                'shipping' => $shipping,
                'total' => $subtotal + $shipping,
            ]);

            $order->items()->createMany($lines);
        }

        // ── Demandes d'intervention ───────────────────────────────────────
        $technician = Technician::where('is_available', true)->first();

        $requests = [
            [
                'reference' => 'INT-DEMO-001',
                'service' => 'Dépannage urgence',
                'description' => "Fuite sous l'évier de la cuisine, le joint semble percé.",
                'status' => TechnicianRequestStatus::Assigned,
                'technician_id' => $technician?->id,
            ],
            [
                'reference' => 'INT-DEMO-002',
                'service' => 'Pose de chauffe-eau',
                'description' => 'Installation d\'un chauffe-eau 150L dans la salle de bain.',
                'status' => TechnicianRequestStatus::Pending,
                'technician_id' => null,
            ],
        ];

        foreach ($requests as $request) {
            TechnicianRequest::firstOrCreate(
                ['reference' => $request['reference']],
                [
                    'user_id' => $customer->id,
                    'technician_id' => $request['technician_id'],
                    'customer_name' => $customer->name,
                    'customer_phone' => $customer->phone ?? '+237 690 11 22 33',
                    'address' => $customer->address ?? 'Bastos, Yaoundé',
                    'service' => $request['service'],
                    'preferred_date' => now()->addDays(3)->toDateString(),
                    'preferred_time' => '09:00',
                    'description' => $request['description'],
                    'status' => $request['status'],
                ],
            );
        }

        // ── Avis produit ──────────────────────────────────────────────────
        $reviewed = $products->first();

        Review::firstOrCreate(
            ['product_id' => $reviewed->id, 'user_id' => $customer->id],
            [
                'rating' => 5,
                'body' => 'Très bon produit, conforme à la description. Livraison rapide au Cameroun.',
            ],
        );

        $reviewed->refreshRating();

        // ── Message de contact ────────────────────────────────────────────
        ContactMessage::firstOrCreate(
            ['phone' => '+237 690 44 55 66', 'name' => 'Alice Kamga'],
            [
                'email' => 'alice.kamga@example.cm',
                'subject' => 'devis',
                'message' => 'Bonjour, je souhaite un devis pour la rénovation complète de ma salle de bain.',
                'status' => ContactMessageStatus::New,
            ],
        );
    }

    /**
     * Prix unitaire applicable pour une quantité, d'après les paliers du produit.
     */
    private function tierPrice(Product $product, int $quantity): int
    {
        $price = $product->price;

        foreach ($product->priceTiers as $tier) {
            if ($quantity >= $tier->min_qty) {
                $price = $tier->price;
            }
        }

        return $price;
    }
}
