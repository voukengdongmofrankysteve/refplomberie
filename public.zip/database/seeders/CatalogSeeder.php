<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CatalogSeeder extends Seeder
{
    /**
     * Catégories, produits, galeries et paliers de prix de démarrage.
     */
    public function run(): void
    {
        $categories = [
            ['slug' => 'robinetterie', 'label' => 'Robinetterie'],
            ['slug' => 'tuyauterie', 'label' => 'Tuyauterie & Raccords'],
            ['slug' => 'sanitaire', 'label' => 'Sanitaire'],
            ['slug' => 'chauffe-eau', 'label' => 'Chauffe-eau'],
            ['slug' => 'outils', 'label' => 'Outils & Accessoires'],
        ];

        foreach ($categories as $position => $category) {
            Category::updateOrCreate(
                ['slug' => $category['slug']],
                ['label' => $category['label'], 'position' => $position],
            );
        }

        /** @var array<int, array<string, mixed>> $products */
        $products = require __DIR__.'/data/products.php';

        foreach ($products as $data) {
            $category = Category::where('slug', $data['category'])->firstOrFail();

            $product = Product::updateOrCreate(
                ['slug' => Str::slug($data['name'])],
                [
                    'category_id' => $category->id,
                    'name' => $data['name'],
                    'description' => $data['desc'],
                    'price' => $data['price'],
                    'old_price' => $data['oldPrice'],
                    'badge' => $data['badge'],
                    'image' => $data['img'],
                    'rating' => $data['rating'],
                    'reviews_count' => $data['reviews'],
                    'stock' => $data['stock'],
                    'is_active' => true,
                ],
            );

            // Le seeder est ré-exécutable : on repart d'une galerie propre.
            $product->images()->delete();

            foreach ($data['images'] as $position => $url) {
                $product->images()->create(['url' => $url, 'position' => $position]);
            }

            $product->priceTiers()->delete();

            foreach ($data['priceTiers'] as $tier) {
                $product->priceTiers()->create([
                    'min_qty' => $tier['minQty'],
                    'max_qty' => $tier['maxQty'],
                    'price' => $tier['price'],
                ]);
            }
        }
    }
}
