<?php if($response): ?>
<?php echo $response->head; ?>

<?php else: ?>
<?php echo $slot; ?>

<?php endif; ?><?php /**PATH C:\Users\HP\Desktop\projet\VYLOXI\libxaprojet\referenceplomb\storage\framework\views/58f6b5ecbad88fc4da15879dbc7f6e69.blade.php ENDPATH**/ ?>