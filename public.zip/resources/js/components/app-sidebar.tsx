import { Link, usePage } from '@inertiajs/react';
import {
    ClipboardList,
    Heart,
    LayoutGrid,
    MessageSquare,
    Package,
    ReceiptText,
    Store,
    Users,
    Wrench,
} from 'lucide-react';
import AppLogo from '@/components/app-logo';
import { NavFooter } from '@/components/nav-footer';
import { NavMain } from '@/components/nav-main';
import { NavUser } from '@/components/nav-user';
import {
    Sidebar,
    SidebarContent,
    SidebarFooter,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
} from '@/components/ui/sidebar';
import { dashboard, home } from '@/routes';
import * as account from '@/routes/account';
import admin from '@/routes/admin';
import type { NavItem } from '@/types';

/** Navigation de l'espace client. */
const customerNavItems: NavItem[] = [
    { title: 'Tableau de bord', href: dashboard(), icon: LayoutGrid },
    { title: 'Mes favoris', href: account.favorites(), icon: Heart },
    { title: 'Mes commandes', href: account.orders(), icon: ReceiptText },
    {
        title: 'Mes interventions',
        href: account.technicianRequests(),
        icon: Wrench,
    },
];

/** Navigation du back-office. */
const adminNavItems: NavItem[] = [
    { title: 'Vue d’ensemble', href: admin.dashboard(), icon: LayoutGrid },
    { title: 'Produits', href: admin.products.index(), icon: Package },
    { title: 'Commandes', href: admin.orders.index(), icon: ReceiptText },
    {
        title: 'Interventions',
        href: admin.technicianRequests.index(),
        icon: ClipboardList,
    },
    { title: 'Techniciens', href: admin.technicians.index(), icon: Wrench },
    { title: 'Messages', href: admin.messages.index(), icon: MessageSquare },
    { title: 'Comptes', href: admin.customers.index(), icon: Users },
];

const footerNavItems: NavItem[] = [
    { title: 'Voir la boutique', href: home(), icon: Store },
];

export function AppSidebar() {
    const { auth } = usePage().props;
    const isAdmin = auth.isAdmin;

    const items = isAdmin ? adminNavItems : customerNavItems;
    const homeHref = isAdmin ? admin.dashboard() : dashboard();

    return (
        <Sidebar collapsible="icon" variant="inset">
            <SidebarHeader>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton size="lg" asChild>
                            <Link href={homeHref} prefetch>
                                <AppLogo />
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarHeader>

            <SidebarContent>
                <NavMain
                    items={items}
                    label={isAdmin ? 'Administration' : 'Mon espace'}
                />
            </SidebarContent>

            <SidebarFooter>
                <NavFooter items={footerNavItems} className="mt-auto" />
                <NavUser />
            </SidebarFooter>
        </Sidebar>
    );
}
