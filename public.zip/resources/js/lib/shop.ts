import { product } from '@/routes/shop';
import type { PriceTier } from '@/types/shop';

/** Formatage monétaire FCFA utilisé dans toute la vitrine. */
export function formatPrice(n: number): string {
    return `${new Intl.NumberFormat('fr-FR').format(n)} FCFA`;
}

/**
 * URL de la page détail d'un produit (route `shop.product`, via Wayfinder).
 * Le modèle est lié par son slug.
 */
export function productUrl(slug: string): string {
    return product.url(slug);
}

/** Frais de port appliqués à un sous-total, selon les règles du magasin. */
export function shippingFor(
    subtotal: number,
    store: { shippingCost: number; freeShippingFrom: number },
): number {
    return subtotal >= store.freeShippingFrom ? 0 : store.shippingCost;
}

/** Palier tarifaire applicable pour une quantité donnée. */
export function getActiveTier(
    priceTiers: PriceTier[] | undefined,
    qty: number,
): PriceTier | null {
    if (!priceTiers || priceTiers.length === 0) {
        return null;
    }

    let active = priceTiers[0];

    for (const tier of priceTiers) {
        if (qty >= tier.minQty) {
            active = tier;
        }
    }

    return active;
}

/** Pourcentage de remise par rapport à l'ancien prix. */
export function getDiscount(
    price: number,
    oldPrice: number | null,
): number | null {
    if (!oldPrice) {
        return null;
    }

    return Math.round((1 - price / oldPrice) * 100);
}

/** Ouvre WhatsApp avec un message pré-rempli. */
export function openWhatsApp(phone: string, message: string): void {
    window.open(
        `https://wa.me/${phone}?text=${encodeURIComponent(message)}`,
        '_blank',
    );
}
