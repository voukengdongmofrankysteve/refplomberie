import DashboardController from './DashboardController'
import FavoriteController from './FavoriteController'
import OrderController from './OrderController'
import TechnicianRequestController from './TechnicianRequestController'
const Account = {
    DashboardController: Object.assign(DashboardController, DashboardController),
FavoriteController: Object.assign(FavoriteController, FavoriteController),
OrderController: Object.assign(OrderController, OrderController),
TechnicianRequestController: Object.assign(TechnicianRequestController, TechnicianRequestController),
}

export default Account