import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Account\FavoriteController::index
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mes-favoris',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\FavoriteController::index
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\FavoriteController::index
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\FavoriteController::index
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\FavoriteController::index
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\FavoriteController::index
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\FavoriteController::index
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const FavoriteController = { index }

export default FavoriteController