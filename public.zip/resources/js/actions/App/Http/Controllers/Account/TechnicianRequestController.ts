import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::index
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mes-interventions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::index
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::index
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::index
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\TechnicianRequestController::index
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\TechnicianRequestController::index
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\TechnicianRequestController::index
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const TechnicianRequestController = { index }

export default TechnicianRequestController