import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Account\OrderController::index
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mes-commandes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\OrderController::index
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\OrderController::index
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\OrderController::index
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\OrderController::index
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\OrderController::index
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\OrderController::index
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const OrderController = { index }

export default OrderController