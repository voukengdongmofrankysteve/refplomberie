import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TechnicianRequestController::store
 * @see app/Http/Controllers/TechnicianRequestController.php:14
 * @route '/interventions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/interventions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TechnicianRequestController::store
 * @see app/Http/Controllers/TechnicianRequestController.php:14
 * @route '/interventions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TechnicianRequestController::store
 * @see app/Http/Controllers/TechnicianRequestController.php:14
 * @route '/interventions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TechnicianRequestController::store
 * @see app/Http/Controllers/TechnicianRequestController.php:14
 * @route '/interventions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TechnicianRequestController::store
 * @see app/Http/Controllers/TechnicianRequestController.php:14
 * @route '/interventions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const TechnicianRequestController = { store }

export default TechnicianRequestController