import ShopController from './ShopController'
import OrderController from './OrderController'
import TechnicianRequestController from './TechnicianRequestController'
import ContactMessageController from './ContactMessageController'
import Account from './Account'
import FavoriteController from './FavoriteController'
import ReviewController from './ReviewController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    ShopController: Object.assign(ShopController, ShopController),
OrderController: Object.assign(OrderController, OrderController),
TechnicianRequestController: Object.assign(TechnicianRequestController, TechnicianRequestController),
ContactMessageController: Object.assign(ContactMessageController, ContactMessageController),
Account: Object.assign(Account, Account),
FavoriteController: Object.assign(FavoriteController, FavoriteController),
ReviewController: Object.assign(ReviewController, ReviewController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers