import DashboardController from './DashboardController'
import ProductController from './ProductController'
import OrderController from './OrderController'
import TechnicianController from './TechnicianController'
import TechnicianRequestController from './TechnicianRequestController'
import ContactMessageController from './ContactMessageController'
import CustomerController from './CustomerController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
ProductController: Object.assign(ProductController, ProductController),
OrderController: Object.assign(OrderController, OrderController),
TechnicianController: Object.assign(TechnicianController, TechnicianController),
TechnicianRequestController: Object.assign(TechnicianRequestController, TechnicianRequestController),
ContactMessageController: Object.assign(ContactMessageController, ContactMessageController),
CustomerController: Object.assign(CustomerController, CustomerController),
}

export default Admin