import type { Auth } from '@/types/auth';
import type { Product, StoreInfo } from '@/types/shop';

declare module 'react' {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    interface InputHTMLAttributes<T> {
        passwordrules?: string;
    }
}

declare module '@inertiajs/core' {
    export interface InertiaConfig {
        sharedPageProps: {
            name: string;
            auth: Auth & { isAdmin: boolean };
            sidebarOpen: boolean;
            store: StoreInfo;
            favorites: Product[];
            flash: { success: string | null; error: string | null };
            [key: string]: unknown;
        };
    }
}
