export type PriceTier = {
    minQty: number;
    maxQty: number | null;
    price: number;
};

export type Product = {
    id: number;
    slug: string;
    category: string;
    categoryLabel: string;
    name: string;
    desc: string;
    price: number;
    oldPrice: number | null;
    badge: string | null;
    img: string;
    images: string[];
    rating: number;
    reviews: number;
    stock: number;
    priceTiers: PriceTier[];
};

export type Category = {
    id: string;
    label: string;
};

export type StoreInfo = {
    name: string;
    address: string;
    phone: string;
    whatsapp: string;
    email: string;
    hours: string;
    shippingCost: number;
    freeShippingFrom: number;
};

export type CartItem = Product & { qty: number };

export type ProductReview = {
    id: number;
    author: string;
    avatar: string;
    rating: number;
    text: string;
    date: string;
};

export type Technician = {
    id: number;
    name: string;
    specialty: string;
    experience: string;
    rating: number;
    jobs: number;
    img: string;
    available: boolean;
};

export type OrderItem = {
    id: number;
    productName: string;
    unitPrice: number;
    quantity: number;
    lineTotal: number;
};

export type Order = {
    id: number;
    reference: string;
    customerName: string;
    customerPhone: string;
    customerAddress: string | null;
    status: string;
    statusLabel: string;
    subtotal: number;
    shipping: number;
    total: number;
    note: string | null;
    createdAt: string;
    accountEmail?: string | null;
    items?: OrderItem[];
    itemsCount?: number;
};

export type TechnicianRequest = {
    id: number;
    reference: string;
    customerName: string;
    customerPhone: string;
    address: string;
    service: string;
    preferredDate: string | null;
    preferredTime: string | null;
    description: string;
    status: string;
    statusLabel: string;
    adminNote: string | null;
    technicianId: number | null;
    technicianName?: string | null;
    accountEmail?: string | null;
    createdAt: string;
};

export type ContactMessage = {
    id: number;
    name: string;
    email: string | null;
    phone: string;
    subject: string | null;
    message: string;
    status: string;
    statusLabel: string;
    createdAt: string;
};

export type StatusOption = {
    value: string;
    label: string;
};

/** Lien de pagination rendu par Laravel. */
export type PaginationLink = {
    url: string | null;
    label: string;
    active: boolean;
};

/** `paginate()->through()` — la forme « simple », sans enveloppe `data`. */
export type Paginated<T> = {
    data: T[];
    links: PaginationLink[];
    current_page: number;
    last_page: number;
    total: number;
    from: number | null;
    to: number | null;
};

/** Collection de ressources paginée : `meta` et `links` sont séparés. */
export type PaginatedResource<T> = {
    data: T[];
    links: {
        first: string | null;
        last: string | null;
        prev: string | null;
        next: string | null;
    };
    meta: {
        current_page: number;
        last_page: number;
        total: number;
        from: number | null;
        to: number | null;
        links: PaginationLink[];
    };
};
