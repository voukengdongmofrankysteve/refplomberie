import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::index
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:21
 * @route '/admin/technician-requests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/technician-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::index
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:21
 * @route '/admin/technician-requests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::index
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:21
 * @route '/admin/technician-requests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::index
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:21
 * @route '/admin/technician-requests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::index
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:21
 * @route '/admin/technician-requests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::index
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:21
 * @route '/admin/technician-requests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::index
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:21
 * @route '/admin/technician-requests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::show
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:48
 * @route '/admin/technician-requests/{technicianRequest}'
 */
export const show = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/technician-requests/{technicianRequest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::show
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:48
 * @route '/admin/technician-requests/{technicianRequest}'
 */
show.url = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { technicianRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { technicianRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    technicianRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        technicianRequest: typeof args.technicianRequest === 'object'
                ? args.technicianRequest.id
                : args.technicianRequest,
                }

    return show.definition.url
            .replace('{technicianRequest}', parsedArgs.technicianRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::show
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:48
 * @route '/admin/technician-requests/{technicianRequest}'
 */
show.get = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::show
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:48
 * @route '/admin/technician-requests/{technicianRequest}'
 */
show.head = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::show
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:48
 * @route '/admin/technician-requests/{technicianRequest}'
 */
    const showForm = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::show
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:48
 * @route '/admin/technician-requests/{technicianRequest}'
 */
        showForm.get = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::show
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:48
 * @route '/admin/technician-requests/{technicianRequest}'
 */
        showForm.head = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::update
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:62
 * @route '/admin/technician-requests/{technicianRequest}'
 */
export const update = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/technician-requests/{technicianRequest}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::update
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:62
 * @route '/admin/technician-requests/{technicianRequest}'
 */
update.url = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { technicianRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { technicianRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    technicianRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        technicianRequest: typeof args.technicianRequest === 'object'
                ? args.technicianRequest.id
                : args.technicianRequest,
                }

    return update.definition.url
            .replace('{technicianRequest}', parsedArgs.technicianRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::update
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:62
 * @route '/admin/technician-requests/{technicianRequest}'
 */
update.put = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::update
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:62
 * @route '/admin/technician-requests/{technicianRequest}'
 */
    const updateForm = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::update
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:62
 * @route '/admin/technician-requests/{technicianRequest}'
 */
        updateForm.put = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::destroy
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:84
 * @route '/admin/technician-requests/{technicianRequest}'
 */
export const destroy = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/technician-requests/{technicianRequest}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::destroy
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:84
 * @route '/admin/technician-requests/{technicianRequest}'
 */
destroy.url = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { technicianRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { technicianRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    technicianRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        technicianRequest: typeof args.technicianRequest === 'object'
                ? args.technicianRequest.id
                : args.technicianRequest,
                }

    return destroy.definition.url
            .replace('{technicianRequest}', parsedArgs.technicianRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::destroy
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:84
 * @route '/admin/technician-requests/{technicianRequest}'
 */
destroy.delete = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::destroy
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:84
 * @route '/admin/technician-requests/{technicianRequest}'
 */
    const destroyForm = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\TechnicianRequestController::destroy
 * @see app/Http/Controllers/Admin/TechnicianRequestController.php:84
 * @route '/admin/technician-requests/{technicianRequest}'
 */
        destroyForm.delete = (args: { technicianRequest: number | { id: number } } | [technicianRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const technicianRequests = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default technicianRequests