import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Account\FavoriteController::favorites
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
export const favorites = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: favorites.url(options),
    method: 'get',
})

favorites.definition = {
    methods: ["get","head"],
    url: '/mes-favoris',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\FavoriteController::favorites
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
favorites.url = (options?: RouteQueryOptions) => {
    return favorites.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\FavoriteController::favorites
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
favorites.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: favorites.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\FavoriteController::favorites
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
favorites.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: favorites.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\FavoriteController::favorites
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
    const favoritesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: favorites.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\FavoriteController::favorites
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
        favoritesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: favorites.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\FavoriteController::favorites
 * @see app/Http/Controllers/Account/FavoriteController.php:16
 * @route '/mes-favoris'
 */
        favoritesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: favorites.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    favorites.form = favoritesForm
/**
* @see \App\Http\Controllers\Account\OrderController::orders
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
export const orders = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders.url(options),
    method: 'get',
})

orders.definition = {
    methods: ["get","head"],
    url: '/mes-commandes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\OrderController::orders
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
orders.url = (options?: RouteQueryOptions) => {
    return orders.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\OrderController::orders
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
orders.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\OrderController::orders
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
orders.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orders.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\OrderController::orders
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
    const ordersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: orders.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\OrderController::orders
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
        ordersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: orders.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\OrderController::orders
 * @see app/Http/Controllers/Account/OrderController.php:16
 * @route '/mes-commandes'
 */
        ordersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: orders.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    orders.form = ordersForm
/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::technicianRequests
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
export const technicianRequests = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: technicianRequests.url(options),
    method: 'get',
})

technicianRequests.definition = {
    methods: ["get","head"],
    url: '/mes-interventions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::technicianRequests
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
technicianRequests.url = (options?: RouteQueryOptions) => {
    return technicianRequests.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::technicianRequests
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
technicianRequests.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: technicianRequests.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Account\TechnicianRequestController::technicianRequests
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
technicianRequests.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: technicianRequests.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Account\TechnicianRequestController::technicianRequests
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
    const technicianRequestsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: technicianRequests.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Account\TechnicianRequestController::technicianRequests
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
        technicianRequestsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: technicianRequests.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Account\TechnicianRequestController::technicianRequests
 * @see app/Http/Controllers/Account/TechnicianRequestController.php:16
 * @route '/mes-interventions'
 */
        technicianRequestsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: technicianRequests.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    technicianRequests.form = technicianRequestsForm
const account = {
    favorites: Object.assign(favorites, favorites),
orders: Object.assign(orders, orders),
technicianRequests: Object.assign(technicianRequests, technicianRequests),
}

export default account