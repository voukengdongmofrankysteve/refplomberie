import { Head, Link } from '@inertiajs/react';
import {
    ClipboardList,
    MessageSquare,
    Package,
    PackageX,
    ReceiptText,
    Users,
    Wallet,
} from 'lucide-react';
import StatCard from '@/components/dashboard/stat-card';
import StatusBadge from '@/components/dashboard/status-badge';
import { formatPrice } from '@/lib/shop';
import admin from '@/routes/admin';
import type { Order, TechnicianRequest } from '@/types/shop';

type Props = {
    stats: {
        revenue: number;
        orders: number;
        pendingOrders: number;
        products: number;
        outOfStock: number;
        customers: number;
        pendingRequests: number;
        newMessages: number;
    };
    recentOrders: Order[];
    recentRequests: TechnicianRequest[];
    ordersByStatus: { status: string; label: string; count: number }[];
};

export default function AdminDashboard({
    stats,
    recentOrders,
    recentRequests,
    ordersByStatus,
}: Props) {
    const maxCount = Math.max(...ordersByStatus.map((s) => s.count), 1);

    return (
        <>
            <Head title="Administration" />

            <div className="flex h-full flex-1 flex-col gap-4 overflow-x-auto p-4">
                <div>
                    <h1 className="text-lg font-semibold">Vue d’ensemble</h1>
                    <p className="text-sm text-muted-foreground">
                        Activité de la boutique Réf. Plomberie.
                    </p>
                </div>

                {/* Chiffres clés */}
                <div className="grid auto-rows-min gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    <StatCard
                        label="Chiffre d’affaires"
                        value={formatPrice(stats.revenue)}
                        hint="Commandes non annulées"
                        icon={Wallet}
                    />
                    <StatCard
                        label="Commandes"
                        value={stats.orders}
                        hint={`${stats.pendingOrders} en attente`}
                        icon={ReceiptText}
                    />
                    <StatCard
                        label="Produits"
                        value={stats.products}
                        hint={`${stats.outOfStock} en rupture`}
                        icon={stats.outOfStock > 0 ? PackageX : Package}
                    />
                    <StatCard
                        label="Comptes"
                        value={stats.customers}
                        icon={Users}
                    />
                    <StatCard
                        label="Interventions à traiter"
                        value={stats.pendingRequests}
                        icon={ClipboardList}
                    />
                    <StatCard
                        label="Nouveaux messages"
                        value={stats.newMessages}
                        icon={MessageSquare}
                    />
                </div>

                <div className="grid gap-4 lg:grid-cols-3">
                    {/* Répartition par statut */}
                    <section className="rounded-xl border border-sidebar-border/70 bg-card dark:border-sidebar-border">
                        <header className="border-b border-sidebar-border/70 px-4 py-3 dark:border-sidebar-border">
                            <h2 className="text-sm font-semibold">
                                Commandes par statut
                            </h2>
                        </header>
                        <ul className="space-y-3 p-4">
                            {ordersByStatus.map((row) => (
                                <li key={row.status}>
                                    <div className="mb-1 flex items-center justify-between text-xs">
                                        <span className="text-muted-foreground">
                                            {row.label}
                                        </span>
                                        <span className="font-semibold">
                                            {row.count}
                                        </span>
                                    </div>
                                    <div
                                        className="h-1.5 rounded-full bg-muted"
                                        role="presentation"
                                    >
                                        <div
                                            className="h-1.5 rounded-full bg-primary"
                                            style={{
                                                width: `${(row.count / maxCount) * 100}%`,
                                            }}
                                        />
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </section>

                    {/* Dernières commandes */}
                    <section className="rounded-xl border border-sidebar-border/70 bg-card lg:col-span-2 dark:border-sidebar-border">
                        <header className="flex items-center justify-between border-b border-sidebar-border/70 px-4 py-3 dark:border-sidebar-border">
                            <h2 className="text-sm font-semibold">
                                Dernières commandes
                            </h2>
                            <Link
                                href={admin.orders.index()}
                                className="text-xs font-medium text-primary hover:underline"
                            >
                                Tout voir
                            </Link>
                        </header>

                        {recentOrders.length === 0 ? (
                            <p className="px-4 py-10 text-center text-sm text-muted-foreground">
                                Aucune commande pour le moment.
                            </p>
                        ) : (
                            <ul className="divide-y divide-sidebar-border/70 dark:divide-sidebar-border">
                                {recentOrders.map((order) => (
                                    <li key={order.id}>
                                        <Link
                                            href={admin.orders.show(order.id)}
                                            className="flex items-center justify-between gap-3 px-4 py-3 transition-colors hover:bg-muted/50"
                                        >
                                            <div className="min-w-0">
                                                <p className="truncate text-sm font-medium">
                                                    {order.reference}
                                                </p>
                                                <p className="truncate text-xs text-muted-foreground">
                                                    {order.customerName} ·{' '}
                                                    {order.createdAt}
                                                </p>
                                            </div>
                                            <div className="flex shrink-0 items-center gap-3">
                                                <span className="text-sm font-semibold">
                                                    {formatPrice(order.total)}
                                                </span>
                                                <StatusBadge
                                                    status={order.status}
                                                    label={order.statusLabel}
                                                />
                                            </div>
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </section>
                </div>

                {/* Dernières interventions */}
                <section className="rounded-xl border border-sidebar-border/70 bg-card dark:border-sidebar-border">
                    <header className="flex items-center justify-between border-b border-sidebar-border/70 px-4 py-3 dark:border-sidebar-border">
                        <h2 className="text-sm font-semibold">
                            Dernières demandes d’intervention
                        </h2>
                        <Link
                            href={admin.technicianRequests.index()}
                            className="text-xs font-medium text-primary hover:underline"
                        >
                            Tout voir
                        </Link>
                    </header>

                    {recentRequests.length === 0 ? (
                        <p className="px-4 py-10 text-center text-sm text-muted-foreground">
                            Aucune demande pour le moment.
                        </p>
                    ) : (
                        <ul className="divide-y divide-sidebar-border/70 dark:divide-sidebar-border">
                            {recentRequests.map((request) => (
                                <li key={request.id}>
                                    <Link
                                        href={admin.technicianRequests.show(
                                            request.id,
                                        )}
                                        className="flex items-center justify-between gap-3 px-4 py-3 transition-colors hover:bg-muted/50"
                                    >
                                        <div className="min-w-0">
                                            <p className="truncate text-sm font-medium">
                                                {request.service}
                                            </p>
                                            <p className="truncate text-xs text-muted-foreground">
                                                {request.customerName} ·{' '}
                                                {request.technicianName ??
                                                    'Technicien à assigner'}
                                            </p>
                                        </div>
                                        <StatusBadge
                                            status={request.status}
                                            label={request.statusLabel}
                                        />
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    )}
                </section>
            </div>
        </>
    );
}

AdminDashboard.layout = {
    breadcrumbs: [{ title: 'Administration', href: admin.dashboard() }],
};
