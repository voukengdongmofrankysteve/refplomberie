import { Head, Link, router } from '@inertiajs/react';
import { Package, Pencil, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import type { FormEvent } from 'react';
import EmptyState from '@/components/dashboard/empty-state';
import Pagination from '@/components/dashboard/pagination';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { formatPrice } from '@/lib/shop';
import admin from '@/routes/admin';
import type { Paginated } from '@/types/shop';

type AdminProduct = {
    id: number;
    slug: string;
    name: string;
    category: string;
    price: number;
    stock: number;
    badge: string | null;
    image: string;
    isActive: boolean;
};

type Props = {
    products: Paginated<AdminProduct>;
    categories: { value: number; label: string; slug: string }[];
    filters: { search: string; category: string };
};

const SELECT_CLASS =
    'h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50';

export default function AdminProducts({
    products,
    categories,
    filters,
}: Props) {
    const [search, setSearch] = useState(filters.search);
    const [category, setCategory] = useState(filters.category);

    const applyFilters = (next: { search?: string; category?: string }) =>
        router.get(
            admin.products.index().url,
            { search, category, ...next },
            { preserveState: true, replace: true },
        );

    const handleSearch = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        applyFilters({});
    };

    const destroy = (product: AdminProduct) => {
        if (
            window.confirm(
                `Supprimer définitivement « ${product.name} » ? Cette action est irréversible.`,
            )
        ) {
            router.delete(admin.products.destroy(product.slug).url, {
                preserveScroll: true,
            });
        }
    };

    return (
        <>
            <Head title="Produits" />

            <div className="flex h-full flex-1 flex-col gap-4 p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <h1 className="text-lg font-semibold">Produits</h1>
                        <p className="text-sm text-muted-foreground">
                            {products.total} référence
                            {products.total !== 1 ? 's' : ''} au catalogue.
                        </p>
                    </div>
                    <Button asChild>
                        <Link href={admin.products.create()}>
                            <Plus className="size-4" />
                            Nouveau produit
                        </Link>
                    </Button>
                </div>

                {/* Filtres */}
                <form
                    onSubmit={handleSearch}
                    className="flex flex-wrap items-center gap-2"
                >
                    <Input
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder="Rechercher un produit…"
                        className="w-full sm:w-64"
                        aria-label="Rechercher un produit"
                    />
                    <select
                        className={SELECT_CLASS}
                        value={category}
                        onChange={(e) => {
                            setCategory(e.target.value);
                            applyFilters({ category: e.target.value });
                        }}
                        aria-label="Filtrer par catégorie"
                    >
                        <option value="">Toutes les catégories</option>
                        {categories.map((c) => (
                            <option key={c.value} value={c.slug}>
                                {c.label}
                            </option>
                        ))}
                    </select>
                    <Button type="submit" variant="secondary">
                        Filtrer
                    </Button>
                </form>

                <div className="overflow-hidden rounded-xl border border-sidebar-border/70 bg-card dark:border-sidebar-border">
                    {products.data.length === 0 ? (
                        <EmptyState
                            icon={Package}
                            title="Aucun produit"
                            description="Ajustez vos filtres ou créez une nouvelle référence."
                        />
                    ) : (
                        <>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="border-b border-sidebar-border/70 bg-muted/50 text-left text-xs text-muted-foreground dark:border-sidebar-border">
                                        <tr>
                                            <th className="px-4 py-2.5 font-medium">
                                                Produit
                                            </th>
                                            <th className="px-4 py-2.5 font-medium">
                                                Catégorie
                                            </th>
                                            <th className="px-4 py-2.5 text-right font-medium">
                                                Prix
                                            </th>
                                            <th className="px-4 py-2.5 text-right font-medium">
                                                Stock
                                            </th>
                                            <th className="px-4 py-2.5 font-medium">
                                                État
                                            </th>
                                            <th className="px-4 py-2.5 text-right font-medium">
                                                Actions
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-sidebar-border/70 dark:divide-sidebar-border">
                                        {products.data.map((product) => (
                                            <tr key={product.id}>
                                                <td className="px-4 py-3">
                                                    <div className="flex items-center gap-3">
                                                        <img
                                                            src={product.image}
                                                            alt=""
                                                            className="size-10 shrink-0 rounded-md object-cover"
                                                        />
                                                        <div className="min-w-0">
                                                            <p className="truncate font-medium">
                                                                {product.name}
                                                            </p>
                                                            {product.badge && (
                                                                <span className="text-xs text-muted-foreground">
                                                                    {
                                                                        product.badge
                                                                    }
                                                                </span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="px-4 py-3 text-muted-foreground">
                                                    {product.category}
                                                </td>
                                                <td className="px-4 py-3 text-right font-medium">
                                                    {formatPrice(product.price)}
                                                </td>
                                                <td className="px-4 py-3 text-right">
                                                    <span
                                                        className={
                                                            product.stock === 0
                                                                ? 'font-semibold text-destructive'
                                                                : ''
                                                        }
                                                    >
                                                        {product.stock}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <Badge
                                                        variant={
                                                            product.isActive
                                                                ? 'secondary'
                                                                : 'outline'
                                                        }
                                                    >
                                                        {product.isActive
                                                            ? 'En ligne'
                                                            : 'Masqué'}
                                                    </Badge>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <div className="flex justify-end gap-1">
                                                        <Button
                                                            asChild
                                                            variant="ghost"
                                                            size="icon"
                                                        >
                                                            <Link
                                                                href={admin.products.edit(
                                                                    product.slug,
                                                                )}
                                                                aria-label={`Modifier ${product.name}`}
                                                            >
                                                                <Pencil className="size-4" />
                                                            </Link>
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            onClick={() =>
                                                                destroy(product)
                                                            }
                                                            aria-label={`Supprimer ${product.name}`}
                                                        >
                                                            <Trash2 className="size-4 text-destructive" />
                                                        </Button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            <Pagination
                                links={products.links}
                                from={products.from}
                                to={products.to}
                                total={products.total}
                            />
                        </>
                    )}
                </div>
            </div>
        </>
    );
}

AdminProducts.layout = {
    breadcrumbs: [
        { title: 'Administration', href: admin.dashboard() },
        { title: 'Produits', href: admin.products.index() },
    ],
};
