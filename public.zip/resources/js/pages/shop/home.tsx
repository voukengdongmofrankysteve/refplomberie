import { Head } from '@inertiajs/react';
import Contact from '@/components/shop/contact';
import Hero from '@/components/shop/hero';
import HowItWorks from '@/components/shop/how-it-works';
import Marquee from '@/components/shop/marquee';
import ProductGrid from '@/components/shop/product-grid';
import Services from '@/components/shop/services';
import { StoreMapSection } from '@/components/shop/store-map';
import TechnicianSection from '@/components/shop/technician-section';
import Testimonial from '@/components/shop/testimonial';
import WhyUs from '@/components/shop/why-us';
import type { Category, Product, Technician } from '@/types/shop';

type Props = {
    products: Product[];
    categories: Category[];
    technicians: Technician[];
    services: string[];
};

export default function Home({
    products,
    categories,
    technicians,
    services,
}: Props) {
    return (
        <>
            <Head title="Expert Plomberie en Ligne">
                <meta
                    name="description"
                    content="Robinetterie, tuyauterie, sanitaire et outillage professionnel. Commandez en ligne, confirmez via WhatsApp, livraison rapide partout au Cameroun."
                />
            </Head>

            <main>
                <Hero services={services} />
                <Marquee />
                <ProductGrid products={products} categories={categories} />
                <TechnicianSection
                    technicians={technicians}
                    services={services}
                />
                <HowItWorks />
                <Services />
                <WhyUs />
                <Testimonial />
                <Contact />
                <StoreMapSection />
            </main>
        </>
    );
}
