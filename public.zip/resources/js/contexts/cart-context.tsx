import { router, usePage } from '@inertiajs/react';
import {
    createContext,
    useCallback,
    useContext,
    useMemo,
    useRef,
    useState,
} from 'react';
import type { ReactNode } from 'react';
import { formatPrice, openWhatsApp, shippingFor } from '@/lib/shop';
import { store as storeOrder } from '@/routes/orders';
import type { CartItem, Product } from '@/types/shop';

/** Coordonnées saisies au moment de valider la commande. */
export type CheckoutDetails = {
    customer_name: string;
    customer_phone: string;
    customer_address: string;
    note: string;
};

type CartContextValue = {
    items: CartItem[];
    addItem: (product: Product, qty?: number) => void;
    removeItem: (id: number) => void;
    updateQty: (id: number, qty: number) => void;
    clearCart: () => void;
    totalItems: number;
    subtotal: number;
    shipping: number;
    total: number;
    isOpen: boolean;
    setIsOpen: (open: boolean) => void;
    /** Enregistre la commande en base puis ouvre WhatsApp. */
    checkout: (details: CheckoutDetails) => void;
    isPlacingOrder: boolean;
    toast: string | null;
};

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
    const { store } = usePage().props;
    const [items, setItems] = useState<CartItem[]>([]);
    const [isOpen, setIsOpen] = useState(false);
    const [isPlacingOrder, setIsPlacingOrder] = useState(false);
    const [toast, setToast] = useState<string | null>(null);
    const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

    const showToast = useCallback((msg: string) => {
        setToast(msg);

        if (toastTimer.current) {
            clearTimeout(toastTimer.current);
        }

        toastTimer.current = setTimeout(() => setToast(null), 2500);
    }, []);

    const addItem = useCallback(
        (product: Product, qty = 1) => {
            setItems((prev) => {
                const existing = prev.find((i) => i.id === product.id);

                if (existing) {
                    return prev.map((i) =>
                        i.id === product.id ? { ...i, qty: i.qty + qty } : i,
                    );
                }

                return [...prev, { ...product, qty }];
            });
            showToast(`"${product.name}" ajouté au panier`);
        },
        [showToast],
    );

    const removeItem = useCallback((id: number) => {
        setItems((prev) => prev.filter((i) => i.id !== id));
    }, []);

    const updateQty = useCallback((id: number, qty: number) => {
        if (qty < 1) {
            return;
        }

        setItems((prev) => prev.map((i) => (i.id === id ? { ...i, qty } : i)));
    }, []);

    const clearCart = useCallback(() => setItems([]), []);

    const totalItems = items.reduce((sum, i) => sum + i.qty, 0);
    const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
    const shipping = shippingFor(subtotal, store);
    const total = subtotal + shipping;

    /**
     * La commande est d'abord persistée — le serveur recalcule les prix à
     * partir des paliers — puis le récapitulatif part sur WhatsApp.
     */
    const checkout = useCallback(
        (details: CheckoutDetails) => {
            if (items.length === 0 || isPlacingOrder) {
                return;
            }

            setIsPlacingOrder(true);

            const lines = items.map(
                (i) =>
                    `• ${i.name} x${i.qty} — ${formatPrice(i.price * i.qty)}`,
            );

            router.post(
                storeOrder.url(),
                {
                    ...details,
                    items: items.map((i) => ({
                        product_id: i.id,
                        quantity: i.qty,
                    })),
                },
                {
                    preserveScroll: true,
                    onSuccess: () => {
                        const message =
                            `🛒 *Nouvelle commande — Réf. Plomberie*\n\n` +
                            `Client : ${details.customer_name}\n` +
                            `Téléphone : ${details.customer_phone}\n` +
                            (details.customer_address
                                ? `Adresse : ${details.customer_address}\n`
                                : '') +
                            `\n${lines.join('\n')}\n\n` +
                            `Livraison : ${shipping === 0 ? 'Gratuite' : formatPrice(shipping)}\n` +
                            `*Total : ${formatPrice(total)}*\n\n` +
                            `Merci de confirmer ma commande.`;

                        openWhatsApp(store.whatsapp, message);
                        clearCart();
                        setIsOpen(false);
                    },
                    onFinish: () => setIsPlacingOrder(false),
                },
            );
        },
        [items, isPlacingOrder, shipping, total, store.whatsapp, clearCart],
    );

    const value = useMemo<CartContextValue>(
        () => ({
            items,
            addItem,
            removeItem,
            updateQty,
            clearCart,
            totalItems,
            subtotal,
            shipping,
            total,
            isOpen,
            setIsOpen,
            checkout,
            isPlacingOrder,
            toast,
        }),
        [
            items,
            addItem,
            removeItem,
            updateQty,
            clearCart,
            totalItems,
            subtotal,
            shipping,
            total,
            isOpen,
            checkout,
            isPlacingOrder,
            toast,
        ],
    );

    return (
        <CartContext.Provider value={value}>{children}</CartContext.Provider>
    );
}

export function useCart(): CartContextValue {
    const ctx = useContext(CartContext);

    if (!ctx) {
        throw new Error('useCart must be used inside CartProvider');
    }

    return ctx;
}
