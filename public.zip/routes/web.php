<?php

use App\Http\Controllers\Account;
use App\Http\Controllers\Admin;
use App\Http\Controllers\ContactMessageController;
use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\TechnicianRequestController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Vitrine publique
|--------------------------------------------------------------------------
*/

Route::get('/', [ShopController::class, 'home'])->name('home');
Route::get('produit/{product}', [ShopController::class, 'show'])->name('shop.product');

Route::post('commandes', [OrderController::class, 'store'])->name('orders.store');
Route::post('interventions', [TechnicianRequestController::class, 'store'])
    ->name('technician-requests.store');
Route::post('messages', [ContactMessageController::class, 'store'])
    ->name('contact-messages.store');

/*
|--------------------------------------------------------------------------
| Espace client
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified'])->group(function (): void {
    Route::get('dashboard', Account\DashboardController::class)->name('dashboard');
    Route::get('mes-favoris', [Account\FavoriteController::class, 'index'])
        ->name('account.favorites');
    Route::get('mes-commandes', [Account\OrderController::class, 'index'])
        ->name('account.orders');
    Route::get('mes-interventions', [Account\TechnicianRequestController::class, 'index'])
        ->name('account.technician-requests');

    Route::post('favoris/{product}', [FavoriteController::class, 'toggle'])
        ->name('favorites.toggle');
    Route::post('produit/{product}/avis', [ReviewController::class, 'store'])
        ->name('reviews.store');
});

/*
|--------------------------------------------------------------------------
| Back-office administrateur
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified', 'admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function (): void {
        Route::get('/', Admin\DashboardController::class)->name('dashboard');

        Route::resource('products', Admin\ProductController::class)
            ->except('show');

        Route::get('orders', [Admin\OrderController::class, 'index'])->name('orders.index');
        Route::get('orders/{order}', [Admin\OrderController::class, 'show'])->name('orders.show');
        Route::put('orders/{order}', [Admin\OrderController::class, 'update'])->name('orders.update');
        Route::delete('orders/{order}', [Admin\OrderController::class, 'destroy'])
            ->name('orders.destroy');

        Route::get('technicians', [Admin\TechnicianController::class, 'index'])
            ->name('technicians.index');
        Route::post('technicians', [Admin\TechnicianController::class, 'store'])
            ->name('technicians.store');
        Route::put('technicians/{technician}', [Admin\TechnicianController::class, 'update'])
            ->name('technicians.update');
        Route::delete('technicians/{technician}', [Admin\TechnicianController::class, 'destroy'])
            ->name('technicians.destroy');

        Route::get('technician-requests', [Admin\TechnicianRequestController::class, 'index'])
            ->name('technician-requests.index');
        Route::get('technician-requests/{technicianRequest}', [Admin\TechnicianRequestController::class, 'show'])
            ->name('technician-requests.show');
        Route::put('technician-requests/{technicianRequest}', [Admin\TechnicianRequestController::class, 'update'])
            ->name('technician-requests.update');
        Route::delete('technician-requests/{technicianRequest}', [Admin\TechnicianRequestController::class, 'destroy'])
            ->name('technician-requests.destroy');

        Route::get('messages', [Admin\ContactMessageController::class, 'index'])
            ->name('messages.index');
        Route::put('messages/{message}', [Admin\ContactMessageController::class, 'update'])
            ->name('messages.update');
        Route::delete('messages/{message}', [Admin\ContactMessageController::class, 'destroy'])
            ->name('messages.destroy');

        Route::get('customers', [Admin\CustomerController::class, 'index'])
            ->name('customers.index');
        Route::put('customers/{user}', [Admin\CustomerController::class, 'update'])
            ->name('customers.update');
    });

require __DIR__.'/settings.php';
