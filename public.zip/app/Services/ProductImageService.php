<?php

namespace App\Services;

use GdImage;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Traite les images produit téléversées depuis le back-office.
 *
 * Chaque image est redimensionnée, ré-encodée en WebP (nettement plus léger
 * que le JPEG d'origine) et estampillée du filigrane « Réf.Plomberie /
 * Matériaux & Équipements » avant d'être écrite sur le disque public.
 */
class ProductImageService
{
    /** Largeur maximale conservée pour une image produit. */
    private const MAX_WIDTH = 1600;

    /** Hauteur maximale conservée pour une image produit. */
    private const MAX_HEIGHT = 1600;

    /** Qualité WebP : bon compromis netteté / poids. */
    private const QUALITY = 82;

    private const DISK = 'public';

    private const DIRECTORY = 'products';

    /**
     * Optimise puis stocke une image, et retourne son chemin relatif au disque.
     */
    public function store(UploadedFile $file): string
    {
        $image = $this->decode($file);

        try {
            $image = $this->resize($image);
            $this->watermark($image);

            $path = self::DIRECTORY.'/'.Str::uuid()->toString().'.webp';

            Storage::disk(self::DISK)->put($path, $this->encode($image));

            return $path;
        } finally {
            imagedestroy($image);
        }
    }

    /**
     * Supprime un fichier précédemment stocké.
     *
     * Les URL externes (catalogue de démonstration) sont ignorées : elles ne
     * nous appartiennent pas.
     */
    public function delete(?string $path): void
    {
        if ($path === null || $path === '' || Str::startsWith($path, ['http://', 'https://'])) {
            return;
        }

        Storage::disk(self::DISK)->delete($path);
    }

    /**
     * URL publique d'une image, qu'elle soit stockée localement ou distante.
     */
    public static function url(?string $path): ?string
    {
        if ($path === null || $path === '') {
            return null;
        }

        if (Str::startsWith($path, ['http://', 'https://'])) {
            return $path;
        }

        return Storage::disk(self::DISK)->url($path);
    }

    private function decode(UploadedFile $file): GdImage
    {
        $contents = file_get_contents($file->getRealPath());
        $image = $contents === false ? false : @imagecreatefromstring($contents);

        if (! $image instanceof GdImage) {
            throw new RuntimeException("Image illisible : {$file->getClientOriginalName()}.");
        }

        return $image;
    }

    /**
     * Réduit l'image pour tenir dans le gabarit, sans jamais l'agrandir.
     */
    private function resize(GdImage $image): GdImage
    {
        $width = imagesx($image);
        $height = imagesy($image);

        $ratio = min(self::MAX_WIDTH / $width, self::MAX_HEIGHT / $height, 1);

        if ($ratio >= 1) {
            return $image;
        }

        $targetWidth = max(1, (int) round($width * $ratio));
        $targetHeight = max(1, (int) round($height * $ratio));

        $resized = imagecreatetruecolor($targetWidth, $targetHeight);

        // Un fond blanc évite les aplats noirs si la source est transparente.
        imagefill($resized, 0, 0, imagecolorallocate($resized, 255, 255, 255));
        imagecopyresampled(
            $resized,
            $image,
            0, 0, 0, 0,
            $targetWidth, $targetHeight,
            $width, $height,
        );

        imagedestroy($image);

        return $resized;
    }

    /**
     * Incruste le filigrane de la marque en bas à droite.
     */
    private function watermark(GdImage $image): void
    {
        $font = resource_path('fonts/Outfit-Variable.ttf');

        if (! is_file($font)) {
            return;
        }

        $width = imagesx($image);
        $height = imagesy($image);

        // Tailles proportionnelles : le filigrane reste lisible quel que soit
        // le gabarit, sans jamais manger l'image.
        $titleSize = max(12.0, $width / 28);
        $baselineSize = max(8.0, $width / 58);
        $padding = (int) round($width / 40);

        $title = (string) config('shop.watermark.title');
        $baseline = (string) config('shop.watermark.baseline');

        $titleBox = imagettfbbox($titleSize, 0, $font, $title);
        $baselineBox = imagettfbbox($baselineSize, 0, $font, $baseline);

        if ($titleBox === false || $baselineBox === false) {
            return;
        }

        $titleWidth = $titleBox[2] - $titleBox[0];
        $titleHeight = $titleBox[1] - $titleBox[7];
        $baselineWidth = $baselineBox[2] - $baselineBox[0];
        $baselineHeight = $baselineBox[1] - $baselineBox[7];

        $blockWidth = (int) max($titleWidth, $baselineWidth);
        $gap = (int) round($titleSize * 0.35);
        $blockHeight = (int) ($titleHeight + $gap + $baselineHeight);

        $left = $width - $blockWidth - $padding;
        $top = $height - $blockHeight - $padding;

        imagealphablending($image, true);

        // Voile sombre translucide : garantit le contraste du texte blanc,
        // y compris sur une photo très claire.
        $veil = imagecolorallocatealpha($image, 0, 0, 0, 95);
        imagefilledrectangle(
            $image,
            (int) ($left - $padding / 2),
            (int) ($top - $padding / 2),
            $width,
            $height,
            $veil,
        );

        $shadow = imagecolorallocatealpha($image, 0, 0, 0, 75);
        $white = imagecolorallocatealpha($image, 255, 255, 255, 15);
        $green = imagecolorallocatealpha($image, 37, 211, 102, 15);

        $titleBaseline = (int) ($top + $titleHeight);

        // « Réf. » en blanc, « Plomberie » en vert de marque, comme le logo.
        $prefix = 'Réf.';
        $prefixBox = imagettfbbox($titleSize, 0, $font, $prefix);
        $prefixWidth = $prefixBox === false ? 0 : $prefixBox[2] - $prefixBox[0];

        imagettftext($image, $titleSize, 0, $left + 2, $titleBaseline + 2, $shadow, $font, $prefix);
        imagettftext($image, $titleSize, 0, $left, $titleBaseline, $white, $font, $prefix);

        imagettftext(
            $image,
            $titleSize,
            0,
            (int) ($left + $prefixWidth + 2),
            $titleBaseline + 2,
            $shadow,
            $font,
            'Plomberie',
        );
        imagettftext(
            $image,
            $titleSize,
            0,
            (int) ($left + $prefixWidth),
            $titleBaseline,
            $green,
            $font,
            'Plomberie',
        );

        $baselineY = (int) ($titleBaseline + $gap + $baselineHeight);

        imagettftext($image, $baselineSize, 0, $left + 1, $baselineY + 1, $shadow, $font, $baseline);
        imagettftext($image, $baselineSize, 0, $left, $baselineY, $white, $font, $baseline);
    }

    private function encode(GdImage $image): string
    {
        ob_start();
        imagewebp($image, null, self::QUALITY);

        $contents = ob_get_clean();

        if ($contents === false || $contents === '') {
            throw new RuntimeException("Échec de l'encodage WebP.");
        }

        return $contents;
    }
}
