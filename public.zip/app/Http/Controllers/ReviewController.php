<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Review;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    /**
     * Publie l'avis d'un client sur un produit, puis recalcule sa note.
     */
    public function store(Request $request, Product $product): RedirectResponse
    {
        $data = $request->validate([
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'body' => ['required', 'string', 'min:5', 'max:2000'],
        ], attributes: [
            'rating' => 'note',
            'body' => 'commentaire',
        ]);

        $alreadyReviewed = Review::where('product_id', $product->id)
            ->where('user_id', $request->user()->id)
            ->exists();

        if ($alreadyReviewed) {
            return back()->with('error', 'Vous avez déjà publié un avis sur ce produit.');
        }

        Review::create([
            ...$data,
            'product_id' => $product->id,
            'user_id' => $request->user()->id,
        ]);

        $product->refreshRating();

        return back()->with('success', 'Merci ! Votre avis a été publié.');
    }
}
