<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class FavoriteController extends Controller
{
    /**
     * Ajoute ou retire un produit des favoris du client connecté.
     */
    public function toggle(Request $request, Product $product): RedirectResponse
    {
        $result = $request->user()->favorites()->toggle($product->id);

        $message = in_array($product->id, $result['attached'], strict: true)
            ? "« {$product->name} » ajouté à vos favoris."
            : "« {$product->name} » retiré de vos favoris.";

        return back(fallback: route('home'))->with('success', $message);
    }
}
