<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreOrderRequest;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Enregistre la commande passée depuis le panier.
     *
     * Les prix ne viennent jamais du client : ils sont relus en base et le
     * palier dégressif est appliqué côté serveur.
     */
    public function store(StoreOrderRequest $request): RedirectResponse
    {
        $lines = collect($request->validated('items'))
            ->groupBy('product_id')
            ->map(fn ($group): int => (int) $group->sum('quantity'));

        $products = Product::query()
            ->active()
            ->with('priceTiers')
            ->whereIn('id', $lines->keys())
            ->get()
            ->keyBy('id');

        if ($products->isEmpty()) {
            return back()->with('error', 'Aucun produit disponible dans votre panier.');
        }

        $items = [];
        $subtotal = 0;

        foreach ($lines as $productId => $quantity) {
            $product = $products->get($productId);

            if ($product === null) {
                continue;
            }

            $unitPrice = $this->tierPrice($product, $quantity);
            $lineTotal = $unitPrice * $quantity;
            $subtotal += $lineTotal;

            $items[] = [
                'product_id' => $product->id,
                'product_name' => $product->name,
                'unit_price' => $unitPrice,
                'quantity' => $quantity,
                'line_total' => $lineTotal,
            ];
        }

        $shipping = $subtotal >= (int) config('shop.shipping.free_from')
            ? 0
            : (int) config('shop.shipping.cost');

        $order = DB::transaction(function () use ($request, $items, $subtotal, $shipping): Order {
            $order = Order::create([
                'reference' => Order::generateReference(),
                'user_id' => $request->user()?->id,
                'customer_name' => $request->validated('customer_name'),
                'customer_phone' => $request->validated('customer_phone'),
                'customer_address' => $request->validated('customer_address'),
                'subtotal' => $subtotal,
                'shipping' => $shipping,
                'total' => $subtotal + $shipping,
                'note' => $request->validated('note'),
            ]);

            $order->items()->createMany($items);

            return $order;
        });

        return back()->with('success', "Commande {$order->reference} enregistrée.");
    }

    /**
     * Prix unitaire applicable pour une quantité, d'après les paliers.
     */
    private function tierPrice(Product $product, int $quantity): int
    {
        $price = $product->price;

        foreach ($product->priceTiers as $tier) {
            if ($quantity >= $tier->min_qty) {
                $price = $tier->price;
            }
        }

        return $price;
    }
}
