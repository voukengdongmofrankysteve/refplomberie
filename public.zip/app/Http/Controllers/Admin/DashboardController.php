<?php

namespace App\Http\Controllers\Admin;

use App\Enums\ContactMessageStatus;
use App\Enums\OrderStatus;
use App\Enums\TechnicianRequestStatus;
use App\Http\Controllers\Controller;
use App\Http\Resources\OrderResource;
use App\Http\Resources\TechnicianRequestResource;
use App\Models\ContactMessage;
use App\Models\Order;
use App\Models\Product;
use App\Models\TechnicianRequest;
use App\Models\User;
use Inertia\Inertia;
use Inertia\Response;

class DashboardController extends Controller
{
    /**
     * Vue d'ensemble : chiffre d'affaires, activité et files d'attente.
     */
    public function __invoke(): Response
    {
        $revenue = (int) Order::whereNot('status', OrderStatus::Cancelled->value)->sum('total');

        return Inertia::render('admin/dashboard', [
            'stats' => [
                'revenue' => $revenue,
                'orders' => Order::count(),
                'pendingOrders' => Order::where('status', OrderStatus::Pending->value)->count(),
                'products' => Product::count(),
                'outOfStock' => Product::where('stock', 0)->count(),
                'customers' => User::count(),
                'pendingRequests' => TechnicianRequest::where(
                    'status',
                    TechnicianRequestStatus::Pending->value,
                )->count(),
                'newMessages' => ContactMessage::where(
                    'status',
                    ContactMessageStatus::New->value,
                )->count(),
            ],
            'recentOrders' => OrderResource::collection(
                Order::with('user')->withCount('items')->latest()->take(6)->get(),
            )->resolve(),
            'recentRequests' => TechnicianRequestResource::collection(
                TechnicianRequest::with(['technician', 'user'])->latest()->take(6)->get(),
            )->resolve(),
            // Alimente le petit graphe « ventes par statut ».
            'ordersByStatus' => collect(OrderStatus::cases())
                ->map(fn (OrderStatus $status): array => [
                    'status' => $status->value,
                    'label' => $status->label(),
                    'count' => Order::where('status', $status->value)->count(),
                ])
                ->all(),
        ]);
    }
}
