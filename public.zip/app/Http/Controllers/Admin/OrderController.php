<?php

namespace App\Http\Controllers\Admin;

use App\Enums\OrderStatus;
use App\Http\Controllers\Controller;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class OrderController extends Controller
{
    /**
     * File des commandes, filtrable par statut et par référence/client.
     */
    public function index(Request $request): Response
    {
        $search = $request->string('search')->trim()->value();
        $status = $request->string('status')->trim()->value();

        $orders = Order::query()
            ->with('user')
            ->withCount('items')
            ->when($search !== '', fn ($query) => $query->where(
                fn ($sub) => $sub->where('reference', 'like', "%{$search}%")
                    ->orWhere('customer_name', 'like', "%{$search}%")
                    ->orWhere('customer_phone', 'like', "%{$search}%"),
            ))
            ->when($status !== '', fn ($query) => $query->where('status', $status))
            ->latest()
            ->paginate(12)
            ->withQueryString();

        return Inertia::render('admin/orders/index', [
            'orders' => OrderResource::collection($orders)->response()->getData(true),
            'statuses' => OrderStatus::options(),
            'filters' => ['search' => $search, 'status' => $status],
        ]);
    }

    public function show(Order $order): Response
    {
        $order->load(['items', 'user']);

        return Inertia::render('admin/orders/show', [
            'order' => (new OrderResource($order))->resolve(),
            'statuses' => OrderStatus::options(),
        ]);
    }

    /**
     * Mise à jour du statut et de la note interne.
     */
    public function update(Request $request, Order $order): RedirectResponse
    {
        $data = $request->validate([
            'status' => ['required', Rule::enum(OrderStatus::class)],
            'note' => ['nullable', 'string', 'max:1000'],
        ], attributes: ['status' => 'statut', 'note' => 'note']);

        $order->update($data);

        return back()->with('success', "Commande {$order->reference} mise à jour.");
    }

    public function destroy(Order $order): RedirectResponse
    {
        $reference = $order->reference;
        $order->delete();

        return to_route('admin.orders.index')
            ->with('success', "Commande {$reference} supprimée.");
    }
}
