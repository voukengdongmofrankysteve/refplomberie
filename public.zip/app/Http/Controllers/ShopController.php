<?php

namespace App\Http\Controllers;

use App\Http\Resources\ProductResource;
use App\Http\Resources\ReviewResource;
use App\Http\Resources\TechnicianResource;
use App\Models\Category;
use App\Models\Product;
use App\Models\Technician;
use Inertia\Inertia;
use Inertia\Response;

class ShopController extends Controller
{
    /**
     * Page d'accueil : catalogue complet et techniciens disponibles.
     */
    public function home(): Response
    {
        $products = Product::query()
            ->active()
            ->with(['category', 'images', 'priceTiers'])
            ->orderBy('id')
            ->get();

        $categories = Category::orderBy('position')
            ->get()
            ->map(fn (Category $category): array => [
                'id' => $category->slug,
                'label' => $category->label,
            ])
            ->all();

        return Inertia::render('shop/home', [
            'products' => ProductResource::collection($products)->resolve(),
            // « Tous les produits » n'existe pas en base : c'est un filtre.
            'categories' => [
                ['id' => 'all', 'label' => 'Tous les produits'],
                ...$categories,
            ],
            'technicians' => TechnicianResource::collection(
                Technician::orderByDesc('is_available')->orderBy('name')->get(),
            )->resolve(),
            'services' => config('shop.services'),
        ]);
    }

    /**
     * Fiche produit, ses avis et les produits de la même catégorie.
     */
    public function show(Product $product): Response
    {
        abort_unless($product->is_active, 404);

        $product->load(['category', 'images', 'priceTiers', 'reviews.user']);

        $related = Product::query()
            ->active()
            ->with(['category', 'images', 'priceTiers'])
            ->where('category_id', $product->category_id)
            ->whereKeyNot($product->id)
            ->take(4)
            ->get();

        return Inertia::render('shop/product', [
            'product' => (new ProductResource($product))->resolve(),
            'related' => ProductResource::collection($related)->resolve(),
            'reviews' => ReviewResource::collection($product->reviews)->resolve(),
            'canReview' => $this->canReview($product),
        ]);
    }

    /**
     * Un client connecté ne peut déposer qu'un seul avis par produit.
     */
    private function canReview(Product $product): bool
    {
        $user = request()->user();

        if ($user === null) {
            return false;
        }

        return ! $product->reviews()->where('user_id', $user->id)->exists();
    }
}
