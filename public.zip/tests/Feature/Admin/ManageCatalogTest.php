<?php

namespace Tests\Feature\Admin;

use App\Enums\OrderStatus;
use App\Enums\TechnicianRequestStatus;
use App\Enums\UserRole;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\Technician;
use App\Models\TechnicianRequest;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ManageCatalogTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private Category $category;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create(['role' => UserRole::Admin]);
        $this->category = Category::create([
            'slug' => 'outils',
            'label' => 'Outils',
        ]);
    }

    public function test_an_administrator_creates_a_product_with_gallery_and_tiers(): void
    {
        $this->actingAs($this->admin)
            ->post(route('admin.products.store'), [
                'category_id' => $this->category->id,
                'name' => 'Clé à molette pro',
                'slug' => 'cle-a-molette-pro',
                'description' => 'Clé à molette professionnelle.',
                'price' => 15000,
                'old_price' => 18000,
                'badge' => 'Nouveau',
                'image' => 'https://example.test/principale.jpg',
                'stock' => 12,
                'is_active' => true,
                'images' => [
                    'https://example.test/1.jpg',
                    'https://example.test/2.jpg',
                ],
                'price_tiers' => [
                    ['min_qty' => 1, 'max_qty' => 9, 'price' => 15000],
                    ['min_qty' => 10, 'max_qty' => null, 'price' => 12000],
                ],
            ])
            ->assertRedirect();

        $product = Product::sole();

        $this->assertSame('cle-a-molette-pro', $product->slug);
        $this->assertSame(2, $product->images()->count());
        $this->assertSame(2, $product->priceTiers()->count());
    }

    public function test_updating_a_product_replaces_its_gallery_and_tiers(): void
    {
        $product = $this->makeProduct();
        $product->images()->create(['url' => 'https://example.test/old.jpg']);
        $product->priceTiers()->create([
            'min_qty' => 1,
            'max_qty' => null,
            'price' => 9000,
        ]);

        $this->actingAs($this->admin)
            ->put(route('admin.products.update', $product), [
                'category_id' => $this->category->id,
                'name' => 'Produit renommé',
                'slug' => $product->slug,
                'description' => 'Nouvelle description.',
                'price' => 11000,
                'old_price' => null,
                'badge' => null,
                'image' => 'https://example.test/principale.jpg',
                'stock' => 3,
                'is_active' => false,
                'images' => ['https://example.test/new.jpg'],
                'price_tiers' => [],
            ])
            ->assertRedirect();

        $product->refresh();

        $this->assertSame('Produit renommé', $product->name);
        $this->assertFalse($product->is_active);
        $this->assertSame(
            ['https://example.test/new.jpg'],
            $product->images()->pluck('url')->all(),
        );
        $this->assertSame(0, $product->priceTiers()->count());
    }

    public function test_an_administrator_deletes_a_product(): void
    {
        $product = $this->makeProduct();

        $this->actingAs($this->admin)
            ->delete(route('admin.products.destroy', $product))
            ->assertRedirect(route('admin.products.index'));

        $this->assertSame(0, Product::count());
    }

    public function test_an_administrator_advances_an_order_status(): void
    {
        $order = Order::create([
            'reference' => 'CMD-TEST-001',
            'customer_name' => 'Jean Mbarga',
            'customer_phone' => '+237 690 00 00 00',
            'subtotal' => 10000,
            'shipping' => 3500,
            'total' => 13500,
        ]);

        $this->actingAs($this->admin)
            ->put(route('admin.orders.update', $order), [
                'status' => OrderStatus::Shipped->value,
                'note' => 'Colis remis au transporteur.',
            ])
            ->assertRedirect();

        $order->refresh();

        $this->assertSame(OrderStatus::Shipped, $order->status);
        $this->assertSame('Colis remis au transporteur.', $order->note);
    }

    public function test_an_administrator_assigns_a_technician_to_a_request(): void
    {
        $technician = Technician::create([
            'name' => 'Paul Nkemdirim',
            'specialty' => 'Plomberie générale',
            'experience' => '8 ans',
            'rating' => 4.9,
            'jobs_count' => 10,
            'photo' => 'https://example.test/paul.jpg',
            'is_available' => true,
        ]);

        $request = TechnicianRequest::create([
            'reference' => 'INT-TEST-001',
            'customer_name' => 'Jean Mbarga',
            'customer_phone' => '+237 690 00 00 00',
            'address' => 'Bastos, Yaoundé',
            'service' => 'Dépannage urgence',
            'description' => 'Fuite au compteur.',
        ]);

        $this->actingAs($this->admin)
            ->put(route('admin.technician-requests.update', $request), [
                'status' => TechnicianRequestStatus::Assigned->value,
                'technician_id' => $technician->id,
                'admin_note' => 'Paul passe demain matin.',
            ])
            ->assertRedirect();

        $request->refresh();

        $this->assertSame(TechnicianRequestStatus::Assigned, $request->status);
        $this->assertSame($technician->id, $request->technician_id);
    }

    public function test_an_administrator_cannot_drop_their_own_admin_role(): void
    {
        $this->actingAs($this->admin)
            ->put(route('admin.customers.update', $this->admin), [
                'role' => UserRole::Customer->value,
            ])
            ->assertSessionHas('error');

        $this->assertTrue($this->admin->fresh()->isAdmin());
    }

    private function makeProduct(): Product
    {
        return Product::create([
            'category_id' => $this->category->id,
            'slug' => 'produit-test',
            'name' => 'Produit test',
            'description' => 'Description de test.',
            'price' => 10000,
            'image' => 'https://example.test/image.jpg',
            'stock' => 5,
            'is_active' => true,
        ]);
    }
}
