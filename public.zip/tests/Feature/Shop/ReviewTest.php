<?php

namespace Tests\Feature\Shop;

use App\Models\Category;
use App\Models\Product;
use App\Models\Review;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReviewTest extends TestCase
{
    use RefreshDatabase;

    public function test_a_guest_cannot_publish_a_review(): void
    {
        $product = $this->makeProduct();

        $this->post(route('reviews.store', $product), [
            'rating' => 5,
            'body' => 'Excellent produit.',
        ])->assertRedirect(route('login'));

        $this->assertSame(0, Review::count());
    }

    public function test_a_review_updates_the_product_rating(): void
    {
        $product = $this->makeProduct();

        $this->actingAs(User::factory()->create())
            ->post(route('reviews.store', $product), [
                'rating' => 4,
                'body' => 'Bon produit, livraison rapide.',
            ])
            ->assertRedirect();

        $product->refresh();

        $this->assertSame(4.0, $product->rating);
        $this->assertSame(1, $product->reviews_count);
    }

    public function test_a_customer_can_only_review_a_product_once(): void
    {
        $product = $this->makeProduct();
        $user = User::factory()->create();

        $this->actingAs($user)->post(route('reviews.store', $product), [
            'rating' => 5,
            'body' => 'Premier avis.',
        ]);

        $this->actingAs($user)
            ->post(route('reviews.store', $product), [
                'rating' => 1,
                'body' => 'Deuxième avis.',
            ])
            ->assertSessionHas('error');

        $this->assertSame(1, Review::count());
    }

    public function test_the_product_page_exposes_published_reviews(): void
    {
        $product = $this->makeProduct();
        $user = User::factory()->create();

        Review::create([
            'product_id' => $product->id,
            'user_id' => $user->id,
            'rating' => 5,
            'body' => 'Parfait.',
        ]);

        $this->get(route('shop.product', $product))
            ->assertInertia(
                fn ($page) => $page
                    ->has('reviews', 1)
                    ->where('reviews.0.text', 'Parfait.')
                    ->where('canReview', false),
            );
    }

    private function makeProduct(): Product
    {
        $category = Category::create(['slug' => 'outils', 'label' => 'Outils']);

        return Product::create([
            'category_id' => $category->id,
            'slug' => 'produit-test',
            'name' => 'Produit test',
            'description' => 'Description de test.',
            'price' => 10000,
            'image' => 'https://example.test/image.jpg',
            'stock' => 5,
            'is_active' => true,
        ]);
    }
}
